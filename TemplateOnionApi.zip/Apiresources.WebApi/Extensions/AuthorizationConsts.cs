﻿
namespace $safeprojectname$.Extensions
{
    public class AuthorizationConsts
    {
        public const string HrAdminPolicy = "HrAdminPolicy";
        public const string ManagerPolicy = "ManagerPolicy";
        public const string EmployeePolicy = "EmployeePolicy";
    }
}
