﻿namespace $safeprojectname$.Enums
{
    public enum Roles
    {
        SuperAdmin,
        HRAdmin,
        Manager,
        Employee
    }
}