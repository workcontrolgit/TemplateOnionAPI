﻿namespace $safeprojectname$.Parameters
{
    public class Order
    {
        public int Column { get; set; }
        public string Dir { get; set; }
    }
}