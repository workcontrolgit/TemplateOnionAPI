﻿namespace $safeprojectname$.Enums
{
    public enum Roles
    {
        SuperAdmin,
        Admin,
        Manager,
        Employee
    }
}