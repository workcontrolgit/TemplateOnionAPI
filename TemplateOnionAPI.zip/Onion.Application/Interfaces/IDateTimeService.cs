﻿using System;

namespace $safeprojectname$.Interfaces
{
    public interface IDateTimeService
    {
        DateTime NowUtc { get; }
    }
}
