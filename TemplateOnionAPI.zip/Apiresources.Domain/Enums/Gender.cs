﻿namespace $safeprojectname$.Enums
{
    public enum Gender
    {
        Male,
        Female
    }
}