﻿using System;

namespace $safeprojectname$.Common
{
    public abstract class BaseEntity
    {
        public virtual Guid Id { get; set; }
    }
}
