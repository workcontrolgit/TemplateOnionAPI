﻿namespace $safeprojectname$.Common
{
    public abstract class BaseEntity
    {
        public virtual int Id { get; set; }
    }
}
