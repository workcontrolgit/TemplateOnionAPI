﻿namespace $safeprojectname$.Models
{
    public class Metadata
    {
    }
}